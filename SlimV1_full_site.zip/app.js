let MAP, EVENTS = [], CURRENT_YEAR = 1500, CURRENT_COUNTRY = null, CURRENT_CITY = null;

const yearSlider = document.getElementById('yearSlider');
const yearLabel = document.getElementById('yearLabel');
const summaryPanel = document.getElementById('summaryPanel');
const summaryBody = document.getElementById('summaryBody');
const nextBtn = document.getElementById('nextBtn');
const categoriesPanel = document.getElementById('categoriesPanel');
const categoryButtons = document.getElementById('categoryButtons');
const resultsPanel = document.getElementById('resultsPanel');
const resultsList = document.getElementById('resultsList');

function initMap() {
  MAP = L.map('map', { zoomControl: true, attributionControl: false }).setView([20, 0], 2);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 6 }).addTo(MAP);
  refresh();
}

function loadData() {
  Papa.parse('data/events.csv', {
    download: true,
    header: true,
    dynamicTyping: true,
    complete: (res) => {
      EVENTS = res.data.filter(r => r && r.title);
      refresh();
    }
  });
}

// Helpers
function isYearInWindow(y) {
  if (typeof y !== 'number') return false;
  return Math.abs(y - CURRENT_YEAR) <= 2; // ±2-year window
}

function mean(coords) {
  const n = coords.length;
  if (!n) return null;
  let lat=0, lng=0, c=0;
  coords.forEach(p => {
    const a = parseFloat(p.lat), b = parseFloat(p.lng);
    if (!isNaN(a) && !isNaN(b)) { lat += a; lng += b; c++; }
  });
  if (!c) return null;
  return {lat: lat/c, lng: lng/c};
}

function clearMarkers() {
  if (window.__markers) { window.__markers.forEach(m => MAP.removeLayer(m)); }
  window.__markers = [];
}

function placeCountryMarkers() {
  clearMarkers();
  const filtered = EVENTS.filter(e => isYearInWindow(e.year));
  const byCountry = {};
  filtered.forEach(e => {
    const key = (e.country || '').trim();
    if (!key) return;
    (byCountry[key] ||= []).push({lat: e.lat, lng: e.lng, title: e.title});
  });
  Object.entries(byCountry).forEach(([country, pts]) => {
    const center = mean(pts);
    if (!center) return;
    const m = L.marker([center.lat, center.lng], {riseOnHover:true}).addTo(MAP);
    m.bindPopup(`<strong>${country}</strong><br/>Click to zoom.`);
    m.on('click', () => onCountry(country));
    window.__markers.push(m);
  });
}

function onCountry(country) {
  CURRENT_COUNTRY = country;
  CURRENT_CITY = null;
  categoriesPanel.classList.add('hidden');
  resultsPanel.classList.add('hidden');

  const countryEvents = EVENTS.filter(e => isYearInWindow(e.year) && (e.country||'').trim() === country);
  const center = mean(countryEvents);
  if (center) MAP.setView([center.lat, center.lng], 5, {animate:true});

  const count = countryEvents.length;
  const sampleTitles = countryEvents.slice(0,3).map(e=>e.title).join('; ');
  summaryBody.innerHTML = `<p><strong>${country}</strong> • ${count} item(s) near ${yearLabel.textContent}.</p>` +
    (count ? `<p>Examples: ${sampleTitles}</p>` : `<p>No entries in this window. Try a nearby year.</p>`);
  nextBtn.classList.remove('hidden');

  // City markers
  clearMarkers();
  const byCity = {};
  countryEvents.forEach(e => {
    let city = '';
    if (e.region && typeof e.region === 'string' && e.region.includes(',')) {
      city = e.region.split(',')[0].trim();
    } else {
      city = (e.region || '').trim() || '(Unknown City)';
    }
    (byCity[city] ||= []).push({lat:e.lat, lng:e.lng, ev:e});
  });
  Object.entries(byCity).forEach(([city, pts]) => {
    const c = mean(pts);
    if (!c) return;
    const m = L.marker([c.lat, c.lng]).addTo(MAP);
    m.bindPopup(`<strong>${city}</strong><br/>Click for summary.`);
    m.on('click', () => onCity(city));
    window.__markers.push(m);
  });
}

function onCity(city) {
  CURRENT_CITY = city;
  const local = EVENTS.filter(e => isYearInWindow(e.year) && (e.country||'').trim() === CURRENT_COUNTRY && (e.region||'').startsWith(city));
  const count = local.length;
  const titles = local.slice(0,3).map(e=>e.title).join('; ');
  summaryBody.innerHTML = `<p><strong>${CURRENT_COUNTRY} — ${city}</strong> • ${count} item(s) near ${yearLabel.textContent}.</p>` +
    (count ? `<p>Examples: ${titles}</p>` : `<p>No entries in this window. Try a nearby year.</p>`);
  nextBtn.classList.remove('hidden');
}

nextBtn.addEventListener('click', () => {
  categoriesPanel.classList.remove('hidden');
  resultsPanel.classList.add('hidden');
  const local = EVENTS.filter(e => isYearInWindow(e.year) && (e.country||'').trim() === (CURRENT_COUNTRY||'') && (CURRENT_CITY ? (e.region||'').startsWith(CURRENT_CITY) : true));
  const cats = [...new Set(local.map(e => e.category).filter(Boolean))].sort();
  categoryButtons.innerHTML = '';
  cats.forEach(cat => {
    const chip = document.createElement('span');
    chip.className = 'category-chip';
    chip.textContent = cat;
    chip.addEventListener('click', ()=> showTopics(cat));
    categoryButtons.appendChild(chip);
  });
  if (cats[0]) showTopics(cats[0]);
});

function showTopics(cat) {
  resultsPanel.classList.remove('hidden');
  const local = EVENTS.filter(e => isYearInWindow(e.year) &&
      (e.country||'').trim() === (CURRENT_COUNTRY||'') &&
      (CURRENT_CITY ? (e.region||'').startsWith(CURRENT_CITY) : true) &&
      e.category === cat);

  const impactRank = {world:0, region:1, country:2, city:3};
  const y = CURRENT_YEAR;
  local.sort((a,b)=>{
    const ia = impactRank[(String(a.impactlevel||'city')).toLowerCase()] ?? 3;
    const ib = impactRank[(String(b.impactlevel||'city')).toLowerCase()] ?? 3;
    if (ia !== ib) return ia - ib;
    const da = Math.abs((a.year||0) - y);
    const db = Math.abs((b.year||0) - y);
    return da - db;
  });

  const top10 = local.slice(0,10);
  resultsList.innerHTML = '';
  top10.forEach(e => {
    const card = document.createElement('div');
    card.className = 'result-card';
    const y = (typeof e.year === 'number') ? e.year : '';
    card.innerHTML = `<h4>${e.title}</h4><div>${e.region || ''}</div><div><em>${e.category}</em> • ${y}</div>`;
    resultsList.appendChild(card);
  });
}

function refresh() {
  yearLabel.textContent = CURRENT_YEAR >= 0 ? CURRENT_YEAR : `${Math.abs(CURRENT_YEAR)} BCE`;
  placeCountryMarkers();
  summaryBody.innerHTML = `Select a country to begin.`;
  nextBtn.classList.add('hidden');
  categoriesPanel.classList.add('hidden');
  resultsPanel.classList.add('hidden');
}

yearSlider.addEventListener('input', (e) => {
  CURRENT_YEAR = parseInt(e.target.value, 10);
  refresh();
});

initMap();
loadData();
